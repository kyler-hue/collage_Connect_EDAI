# forum
forum using html and php
Make database named data and questions and import sql files one by one
